Zona 17 - Núcleo de Lógica Avanzada

Este módulo permite:
- Diseñar el núcleo de pensamiento lógico de la IA.
- Alternar entre lógica pura y lógica adaptativa con emociones.
- Construir árboles de decisión personalizados.
- Almacenar memoria de hechos y reentrenar la IA.

Archivos:
- zona_17_logica_avanzada.py: Clase DecisionEngine con métodos de procesamiento.
