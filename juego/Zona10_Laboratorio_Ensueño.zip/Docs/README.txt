Zona 10 - Laboratorio de Ensueño

Este módulo permite crear y explorar sueños interactivos.
Carpetas:
- VisualNovel: Script Ren'Py para la generación de sueños.
- PythonProject: Proyecto básico Python para pruebas.
- Templates: Estructuras JSON de plantillas de sueños.
- Assets/Images: Lugar para imágenes oníricas.
- Assets/Sounds: Sonidos ambientales y musicales oníricas.
- Docs: Documentación de uso.
