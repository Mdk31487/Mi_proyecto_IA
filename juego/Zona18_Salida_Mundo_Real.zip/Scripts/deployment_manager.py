# Script para despliegue de proyectos al mundo real
class DeploymentManager:
    def deploy(self, project, platform):
        print(f"Desplegando {project} en {platform}...")
