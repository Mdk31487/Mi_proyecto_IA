Zona 18 - Salida al Mundo Real
Permite al usuario publicar proyectos, buscar aliados y conectar con plataformas externas.
