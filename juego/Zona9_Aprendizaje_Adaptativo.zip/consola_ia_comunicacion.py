# Consola IA
print('¿En qué puedo ayudarte hoy?')