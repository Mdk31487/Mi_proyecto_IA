# Script de entrenamiento diario
print('Desafío del día generado.')