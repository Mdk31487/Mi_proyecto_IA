# Zona 8: Cámara de Simulación XR
Este entorno permite experimentar ideas y simular interacciones.
