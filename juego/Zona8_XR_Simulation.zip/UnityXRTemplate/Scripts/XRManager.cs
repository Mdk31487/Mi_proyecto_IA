// Controlador básico para simulaciones XR
