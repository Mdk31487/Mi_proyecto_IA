# Subzona de Aprendizaje Activo
print('Reforzando aprendizajes previos')
