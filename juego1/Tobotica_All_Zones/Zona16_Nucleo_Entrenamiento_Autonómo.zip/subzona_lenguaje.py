# Subzona de Ejercicios de Lenguaje
print('Mejorando estilo comunicativo')
