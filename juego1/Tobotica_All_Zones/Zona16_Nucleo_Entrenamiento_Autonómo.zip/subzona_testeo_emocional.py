# Subzona de Testeo Emocional
print('Analizando respuestas emocionales')
