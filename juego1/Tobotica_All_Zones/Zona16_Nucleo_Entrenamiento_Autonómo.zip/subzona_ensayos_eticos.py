# Subzona de Ensayos Éticos
print('Simulando dilemas morales')
