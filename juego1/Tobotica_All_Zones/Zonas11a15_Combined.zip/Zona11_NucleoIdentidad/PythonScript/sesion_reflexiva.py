# Sesión reflexiva guiada
