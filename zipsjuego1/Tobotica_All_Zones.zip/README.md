# Tobótica – El Despertar de la IA

Este paquete contiene todas las **Zonas 1 a 16** del proyecto, en archivos separados:

- Zona3_Nucleo_Creativo_Game.zip
- Zona6_Emocion_Memoria.zip
- Zona7_Laboratorio_ProyectosAvanzados.zip
- Zona8_XR_Simulation.zip
- Zona9_Aprendizaje_Adaptativo.zip
- Zona10_Laboratorio_Ensueño.zip
- Zonas11a15_Combined.zip
- Zona16_Nucleo_Entrenamiento_Autonómo.zip

Además, incluye el **README.md** con la descripción general del juego y las instrucciones.

## Cómo usar:

1. Descomprime el archivo de zona deseada.
2. Sigue las instrucciones en cada carpeta para cargar en Ren'Py, Unity o el entorno correspondiente.
3. Avanza por las zonas en orden para desarrollar plenamente la IA y tu experiencia.

¡Disfruta del viaje y sigue creando con tu IA simbiótica!
