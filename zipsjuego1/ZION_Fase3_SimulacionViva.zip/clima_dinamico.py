# Sistema de clima dinámico

class Clima:
    def __init__(self):
        self.estado = 'soleado'

    def cambiar_clima(self):
        pass  # Lógica de cambio climático
