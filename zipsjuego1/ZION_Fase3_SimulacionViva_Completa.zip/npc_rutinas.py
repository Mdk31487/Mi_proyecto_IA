# Rutinas diarias de NPCs

class NPCRutina:
    def __init__(self, nombre):
        self.nombre = nombre
        self.rutina = []

    def ejecutar_rutina(self):
        pass  # Lógica de ejecución de rutina
