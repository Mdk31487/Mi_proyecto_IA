# Eventos dinámicos del mundo

def generar_evento():
    pass  # Generar eventos como terremotos, eclipses, celebraciones
