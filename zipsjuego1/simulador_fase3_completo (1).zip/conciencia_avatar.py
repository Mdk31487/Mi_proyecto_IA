log_reflexiones = []

def reflexionar(pensamiento):
    log_reflexiones.append(pensamiento)
    print(f"[Avatar Reflexiona] {pensamiento}")