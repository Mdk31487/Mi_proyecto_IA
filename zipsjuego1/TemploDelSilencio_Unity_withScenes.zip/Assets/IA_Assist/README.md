# IA Assist

Esta carpeta contendrá la lógica de IA y reconocimiento de voz.