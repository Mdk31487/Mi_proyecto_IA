PROYECTO UNITY: TEMPLO DEL SILENCIO

Versión: Unity 2021.3 LTS
Plataformas objetivo: PC, Android, Xbox

Estructura del proyecto:
- Assets/Scenes: escenas del juego (MainMenu, ValleDelEspiritu, etc.)
- Assets/Scripts: lógica del juego
- Assets/Audio: sonidos y música
- Assets/Prefabs: prefabricados de personajes y objetos
- Assets/IA_Assist: lógica de IA, voz y asistencia

Este proyecto incluye escenas básicas, scripts funcionales y placeholders.