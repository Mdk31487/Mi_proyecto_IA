# Fase 2 – Renacer, Poder y Control
Documento global que conecta todas las zonas, su propósito, ubicación, IA asociada, retos y enseñanzas.
Mapa de flujo conceptual en `mapa_flujo.png` (placeholder).
