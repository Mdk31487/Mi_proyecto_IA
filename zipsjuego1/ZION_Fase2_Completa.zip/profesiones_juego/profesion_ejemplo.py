# profesion_ejemplo.py

class ProfesionEjemplo:
    def __init__(self):
        self.nombre = "Ejemplo"
    def ofrecer_servicio(self):
        print("Ofreciendo conocimientos gratuitos y servicio de pago.")
