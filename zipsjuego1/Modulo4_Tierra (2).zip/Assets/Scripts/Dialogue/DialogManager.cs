// DialogManager script placeholder
