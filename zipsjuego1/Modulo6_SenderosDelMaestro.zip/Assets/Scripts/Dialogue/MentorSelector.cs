// Script for selecting mentor in Module 6
