// Script for delivering uniform event
