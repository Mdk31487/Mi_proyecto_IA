ZION SYMBIOS - Visual Novel Interfaz IA

Contenido del paquete:
- script.rpy: Encuesta inicial estilo visual novel.
- Manual_ZION.docx: Manual detallado con espacios para imágenes.
- images/: Carpeta con placeholders para fondos y sprites.

Cómo usar:
1. Copia la carpeta 'ZION_Symbios' a tu proyecto Ren'Py.
2. Asegúrate de colocar las imágenes reales en images/.
3. Inicia la escena 'script.rpy' desde Ren'Py launcher.
