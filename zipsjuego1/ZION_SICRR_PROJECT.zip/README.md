# SICRR_PROJECT
Este sistema centraliza la creación de personajes, mapas y narrativa para el juego ZION usando IA adaptable.
