# Lógica principal para selección de modo de juego
