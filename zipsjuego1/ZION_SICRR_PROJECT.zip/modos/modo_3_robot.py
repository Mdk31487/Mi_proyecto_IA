# Contenido simulado para modo_3_robot.py
