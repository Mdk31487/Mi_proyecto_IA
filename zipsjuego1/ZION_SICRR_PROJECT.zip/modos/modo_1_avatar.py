# Contenido simulado para modo_1_avatar.py
