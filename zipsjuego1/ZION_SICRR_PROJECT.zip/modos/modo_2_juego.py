# Contenido simulado para modo_2_juego.py
