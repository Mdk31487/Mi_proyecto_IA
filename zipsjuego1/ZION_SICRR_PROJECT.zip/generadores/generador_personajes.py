# Contenido simulado para generador_personajes.py
