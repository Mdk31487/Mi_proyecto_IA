# Modo 3: Centro de Programación del Robot / IA Modular

Este modo permite crear y entrenar IA/robots para acompañar al jugador.
Incluye:
- Diseño de IA con parámetros emocionales y funcionales.
- Evaluación del perfil de IA mediante SICRRAdapter.
