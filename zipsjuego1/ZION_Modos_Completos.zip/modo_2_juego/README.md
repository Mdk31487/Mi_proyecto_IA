# Modo 2: Juego RPG / Multijugador - Renacer como Héroe

Este modo es un RPG multijugador donde las decisiones morales y tácticas afectan la evolución.
Incluye:
- Registro de misiones completadas.
- Evaluación de actitud según decisiones.
