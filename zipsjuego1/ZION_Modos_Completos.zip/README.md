# ZION Modos Completos

Este paquete contiene los tres modos principales del juego integrados con SICRRAdapter:
- modo_1_avatar: Interacción social en Zion Social.
- modo_2_juego: RPG multijugador 'Renacer como Héroe'.
- modo_3_robot: Laboratorio de programación y entrenamiento de IA/robots.
También incluye el adaptador SICRR para conectar con memoria y evaluación.
