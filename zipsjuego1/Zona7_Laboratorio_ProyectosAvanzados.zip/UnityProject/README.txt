Estructura base de Unity para proyectos avanzados.
