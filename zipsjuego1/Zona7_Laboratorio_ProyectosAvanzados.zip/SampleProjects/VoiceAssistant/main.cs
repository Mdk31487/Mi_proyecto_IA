using System;
class VoiceAssistant {
    static void Main(string[] args) {
        Console.WriteLine("Asistente de Voz listo. Di 'Hola' para comenzar.");
    }
}
