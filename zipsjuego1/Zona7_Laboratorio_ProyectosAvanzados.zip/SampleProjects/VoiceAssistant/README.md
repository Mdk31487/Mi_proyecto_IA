# Asistente de Voz de Muestra

1. Compila con `csc main.cs`.
2. Ejecuta con `mono main.exe`.
3. Personaliza config.json.
