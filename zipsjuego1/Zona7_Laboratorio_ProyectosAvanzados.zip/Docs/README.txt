Zona 7 - Laboratorio de Proyectos Avanzados

Carpeta VisualNovel: Script para Ren'Py de selección de proyectos.
Carpeta UnityProject: Estructura base de Unity para nuevos proyectos.
SampleProjects/VoiceAssistant: Proyecto de muestra de asistente de voz.
Docs: Documentación descriptiva y guía de integración.
Assets/Visuals: Imágenes conceptuales y placeholders.

En SampleProjects/VoiceAssistant encontrarás:
- main.cs: Script base en C# para un asistente de voz.
- config.json: Configuración de comandos y respuestas.
- README.md: Instrucciones para probar el asistente en PC o Android.